﻿using System;

namespace DefiningClasses
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            int numberOfFamilyMembers = int.Parse(Console.ReadLine());

            var family = new Family();

            for (int i = 0; i < numberOfFamilyMembers; i++)
            {
                var member = Console.ReadLine().Split();

                var memberName = member[0];
                var memberAge = int.Parse(member[1]);

                var person = new Person(memberName,memberAge);

                family.AddMember(person);
            }

            var oldestMember = family.GetOldestMember();

            Console.WriteLine($"{oldestMember.Name} {oldestMember.Age}");
        }
    }
}
