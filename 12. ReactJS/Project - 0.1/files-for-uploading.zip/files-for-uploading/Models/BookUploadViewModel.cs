﻿namespace MyBookcase.Models
{
    public class BookUploadViewModel
    {
        public string Name { get; set; }
        public string Base64File { get; set; }
    }
}
