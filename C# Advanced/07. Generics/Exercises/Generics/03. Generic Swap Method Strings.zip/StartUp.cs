﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Generics
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            var boxes = new List<Box<string>>();

            int numberOfEntries = int.Parse(Console.ReadLine());

            for (int i = 0; i < numberOfEntries; i++)
            {
                var input = Console.ReadLine();
                boxes.Add(new Box<string>(input));
            }

            int[] indexes = Console.ReadLine()
                .Split()
                .Select(int.Parse)
                .ToArray();

            int index1 = indexes[0];
            int index2 = indexes[1];

            Swap(index1, index2, boxes);

            foreach (var box in boxes)
            {
                Console.WriteLine(box);
            }
        }

        static void Swap<T>(int index1, int index2, List<Box<T>> boxes)
        {
            Box<T> temp = boxes[index1];
            boxes[index1] = boxes[index2];
            boxes[index2] = temp;

        }
    }
}
