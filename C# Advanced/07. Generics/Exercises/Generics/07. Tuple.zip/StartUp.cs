﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Generics
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            var input = Console.ReadLine().Split();
            var tuple1 = new Tuple<string, string>(input[0] + " " + input[1], input[2]);
            Console.WriteLine(tuple1);

            input = Console.ReadLine().Split();
            var tuple2 = new Tuple<string, string>(input[0], input[1]);
            Console.WriteLine(tuple2);

            input = Console.ReadLine().Split();
            var tuple3 = new Tuple<string, string>(input[0], input[1]);
            Console.WriteLine(tuple3);
        }
    }
}
