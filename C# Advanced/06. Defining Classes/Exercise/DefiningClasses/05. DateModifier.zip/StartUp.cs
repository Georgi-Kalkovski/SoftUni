﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace DefiningClasses
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            var firstDate = Console.ReadLine();
            var secondDate = Console.ReadLine();

            var dateDifference = new DateModifier();

            Console.WriteLine(dateDifference.CalculateDiff(firstDate, secondDate));

        }
    }
}
