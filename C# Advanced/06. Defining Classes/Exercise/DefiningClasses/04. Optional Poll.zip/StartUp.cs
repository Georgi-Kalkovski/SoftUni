﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace DefiningClasses
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            int numberOfFamilyMembers = int.Parse(Console.ReadLine());

            var people = new List<Person>();

            for (int i = 0; i < numberOfFamilyMembers; i++)
            {
                var member = Console.ReadLine().Split();

                var memberName = member[0];
                var memberAge = int.Parse(member[1]);

                var person = new Person(memberName,memberAge);

                people.Add(person);
            }

            people.Where(a => a.Age > 30)
                .OrderBy(n => n.Name)
                .ToList()
                .ForEach(p => Console.WriteLine($"{p.Name} - {p.Age}"));
        }
    }
}
