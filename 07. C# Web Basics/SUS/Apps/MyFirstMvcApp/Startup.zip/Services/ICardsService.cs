﻿namespace BattleCards.Services
{
    public interface ICardsService
    {
        void AddCard();
    }
}
