﻿namespace BattleCards.Models
{
    public class User
    {
    }
}
