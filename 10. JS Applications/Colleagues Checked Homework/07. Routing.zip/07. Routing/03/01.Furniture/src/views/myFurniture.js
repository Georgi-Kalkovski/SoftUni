export async function myPage(ctx){
    console.log(' page')
}