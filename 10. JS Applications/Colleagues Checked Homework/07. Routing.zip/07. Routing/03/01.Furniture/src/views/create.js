export async function createPage(ctx){
    console.log('create page')
}