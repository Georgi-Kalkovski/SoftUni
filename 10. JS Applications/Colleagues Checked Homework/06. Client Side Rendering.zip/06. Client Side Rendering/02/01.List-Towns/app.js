import { html, render } from '../node_modules/lit-html/lit-html.js';

const root = document.querySelector('#root');
const notification = document.querySelector('.notification');
document.querySelector('form').addEventListener('submit', onSubmit);

function onSubmit(e) {
    e.preventDefault();
    const data = new FormData(e.target);
    const input = data.get('towns').split(',').map(x => x.trim()).filter(x => x !== '');
    if (input.length === 0) {
        return notify(notification,'Input field is required!');
    }
    render(html`<ul>${input.map(x => html`<li>${x}</li>`)}</ul>`, root);
}

function notify(ref, message) {
    ref.textContent = message;
    ref.style.backgroundColor = 'rgba(238, 74, 74, 0.699)';
    setTimeout(() => [ref.textContent = '', ref.style.backgroundColor = ''], 2000);
}