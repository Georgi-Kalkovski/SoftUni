import { html , render} from '../node_modules/lit-html/lit-html.js';
import { cats } from './catSeeder.js';

const main = document.getElementById('allCats');
main.addEventListener('click', showInfo);


const catCard = ({id,statusCode,statusMessage,imageLocation, isVisible}) => html`
<li>
    <img src="./images/${imageLocation}.jpg" width="250" height="250" alt="Card image cap">
    <div class="info">
        <button data-id=${id} class="showBtn">${isVisible ? 'Hide' : 'Show'} status code</button>
        <div class="status" style="display: ${isVisible ? 'black' : 'none'};">
            <h4>Status Code: ${statusCode}</h4>
            <p>${statusMessage}</p>
        </div>
    </div>
</li>`;

render(html`<ul>${cats.map(catCard)}</ul>`, main);

function showInfo(e) {
    if (e.target.classList.contains('showBtn')) {
        const { id } = e.target.dataset;
        const cat = cats.find(c => c.id === id);
        cat.isVisible = !cat.isVisible;
        render(html`<ul>${cats.map(catCard)}</ul>`, main);
    }
}


