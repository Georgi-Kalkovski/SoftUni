import { html , render} from '../node_modules/lit-html/lit-html.js';

const menu = document.getElementById('menu');
const notification = document.querySelector('.notification');
document.querySelector('form').addEventListener('submit', addItem);

const createOption = ({_id,text}) => html`<option value=${_id}>${text}</option>`;
const getData = async () => await (await fetch('http://localhost:3030/jsonstore/advanced/dropdown')).json();
const postData = async data => await fetch('http://localhost:3030/jsonstore/advanced/dropdown',{
    method:'post',
    headers:{ 'Content-Type' : 'application/json'},
    body: JSON.stringify(data)
});

async function start() {
    const data = await getData();
    render(Object.values(data).map(createOption),menu);
}
start();

async function addItem(e) {
    e.preventDefault();
    try {
        const data = new FormData(e.target);
        const text = data.get('item');
        if(text === '') { throw new Error('Input field is required!'); }
        const response = await postData({text});
        if(!response.ok) {
            const {message} = await response.json();
            throw new Error(message);
        }
        start();
        e.target.reset();
    } catch (error) {
        notify(notification,error);
    }
}

function notify(ref, message) {
    ref.textContent = message.toString().slice(7);
    ref.style.backgroundColor = 'cadetblue';
    setTimeout(() => [ref.textContent = '', ref.style.backgroundColor = ''], 2000);
}