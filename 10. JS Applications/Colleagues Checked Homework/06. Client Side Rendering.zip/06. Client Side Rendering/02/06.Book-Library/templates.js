import { html, render } from '../node_modules/lit-html/lit-html.js';
import { put,remove,url } from './utility.js';

const addFormTemplate = () => html`
<form id="add-form">
    <h3>CREATE FORM</h3>
    <label>TITLE</label>
    <input type="text" name="title" placeholder="Title...">
    <label>AUTHOR</label>
    <input type="text" name="author" placeholder="Author...">
    <p class="notification"></p>
    <button>Submit</button>
</form>`;

const editFormTemplate = ({ author, title, id }) => html`
<form id="edit-form">
    <h3>EDIT FORM</h3>
    <label>TITLE</label>
    <input type="text" name="title" placeholder="Title..." .value=${title}>
    <label>AUTHOR</label>
    <input type="text" name="author" placeholder="Author..." .value=${author}>
    <p class="notification"></p>
    <button>Save</button>
    <input type="hidden" name="bookId" placeholder="Title..." .value=${id}>
</form>`;

const createBookTemplate = ({ author, title, id }) => html`
<tr>
    <td>${title}</td>
    <td>${author}</td>
    <td data-id=${id}>
        <button class="edit">Edit</button>
        <button class="delete">Delete</button>
    </td>
</tr>`;

const tableTemplate = (books, loadBooks) => html`
<table>
    <thead>
        <tr>
            <th>Title</th>
            <th>Author</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody @click=${(e) => btnAction(e,books,loadBooks)}>
        ${books.map(createBookTemplate)}
    </tbody>
    <tfoot>
        <tr>
            <td colspan="3">
                <button @click=${loadBooks} id="loadBooks">LOAD ALL BOOKS</button>
            </td>
        </tr>
    </tfoot>
</table>`;

export const layout = (books, bookToEdit, fn) => html`
${tableTemplate(books, fn)}
${bookToEdit ? editFormTemplate(bookToEdit) : addFormTemplate()}`;

async function btnAction(e,books,loadBooks) {
    const { id } = e.target.parentNode.dataset;
    if(e.target.classList.contains('edit')) {
        const book = books.find(b => b.id === id);
        render(layout(books,book,loadBooks),document.querySelector('.container'));

    } else if(e.target.classList.contains('delete')){
        if(confirm('Are you sure ?')) {
            await remove(url+id);
            loadBooks();
        }
    }
}
