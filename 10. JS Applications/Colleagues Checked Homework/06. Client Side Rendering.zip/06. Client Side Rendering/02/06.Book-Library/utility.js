export const url = 'http://localhost:3030/jsonstore/collections/books/';

async function request(type,url,body) {
    const option = { method: type, headers: { 'Content-Type': 'application/json' } };

    if (body) { option.body = JSON.stringify(body); }
    const response = await fetch(url, option);
    if (!response.ok) {
        const { message } = await response.json();
        throw new Error(message);
    }
    return await response.json();
}

export const get = request.bind('null','get'); 
export const post = request.bind('null','post'); 
export const put = request.bind('null','put'); 
export const remove = request.bind('null','delete'); 

export function notify(ref, message) {
    ref.textContent = message.toString().slice(7);
    setTimeout(() => [ref.textContent = '', ref.style.backgroundColor = 'white'], 2000);
}

export function getData(e) {
    e.preventDefault();
    const data = [... new FormData(e.target)].reduce((a, [k, v]) => ({ ...a, ...{ [k]: v } }), {});
    if (Object.values(data).some(x => x === '')) { throw new Error('All fields are required!'); }
    return data;
}