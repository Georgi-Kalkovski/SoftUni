import { render } from '../node_modules/lit-html/lit-html.js';
import { layout } from './templates.js';
import { get, post, put, notify, getData, url } from './utility.js';

const main = document.querySelector('.container');
const actions = {
    'add-form': async data => [await post(url, data), loadBooks()],
    'edit-form': async data => [await put(url + data.bookId, data), loadBooks()]
};

main.addEventListener('submit', onSubmit);

async function onSubmit(e) {
    const notification = e.target.querySelector('.notification');
    try {
        actions[e.target.id](getData(e));
        e.target.reset();
    } catch (error) {
        notify(notification, error);
    }
}

async function loadBooks() {
    const data = await get(url);
    render(layout(Object.entries(data).map(([k, v]) => ({ id: k, ...v })), null, loadBooks), main);
}

(async () => render(layout([], null, loadBooks), main))();



