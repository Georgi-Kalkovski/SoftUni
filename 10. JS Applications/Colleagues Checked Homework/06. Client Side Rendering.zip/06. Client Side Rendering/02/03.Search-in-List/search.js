import { html , render} from '../node_modules/lit-html/lit-html.js';
import { towns } from './towns.js';
const getRef = type => document.querySelector(type);
const compare = (match,t) => match && t.toLowerCase().includes(match.toLowerCase());

const main = document.getElementById('towns');
const [searchText , btn , matches] = [getRef('#searchText'),getRef('button'), getRef('#result') ];
btn.addEventListener('click', search );

const createTown = (town,isActive) => html`<li class="${isActive ? 'active' : '' }">${town}</li>`;
const update = match => render(html`<ul>${towns.map(t => createTown(t ,compare(match,t)))}</ul>`, main);
update(false);

function search () {
   update(searchText.value);
   matches.textContent = searchText.value ? `${towns.filter(t => compare(searchText.value,t)).length} matches found`: '';
}
