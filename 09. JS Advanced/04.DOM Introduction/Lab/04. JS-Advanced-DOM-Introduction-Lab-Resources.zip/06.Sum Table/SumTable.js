function sumTable() {

}